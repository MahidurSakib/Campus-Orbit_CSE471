import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardStudent from './pages/DashboardStudent';
import DashboardAdmin from './pages/DashboardAdmin';
import ClubCreate from './pages/ClubCreate';
import ClubManage from './pages/ClubManage'; 
import Invitations from './pages/Invitations';
import ClubAnnouncementsManage from './pages/ClubAnnouncementsManage';
import ClubAnnouncementsView from './pages/ClubAnnouncementsView';
import ClubActivityManage from './pages/ClubActivityManage';
import ClubActivityView from './pages/ClubActivityView';
import ClubMeetingsManage from './pages/ClubMeetingsManage';
import ClubMeetingsView from './pages/ClubMeetingsView';
import ClubPollsManage from './pages/ClubPollsManage';
import ClubPollsView from './pages/ClubPollsView';
import ResourceUpload from './pages/ResourceUpload';
import Workspace from './pages/Workspace';
import ClubEventsManage from './pages/ClubEventsManage';
import ClubEventsView from './pages/ClubEventsView';
import ClubAchievementsManage from './pages/ClubAchievementsManage';
import ClubAchievementsView from './pages/ClubAchievementsView';
import FeedbackSubmit from './pages/FeedbackSubmit';
import FeedbackView from './pages/FeedbackView';
import ClubContactsManage from './pages/ClubContactsManage';
import ClubContactsView from './pages/ClubContactsView';
import EventPortal from './pages/EventPortal';
import EventDetail from './pages/EventDetail';
import EventGallery from './pages/EventGallery';
import EventCalendar from './pages/EventCalendar';
import AttendeeList from './pages/AttendeeList';
import MyEventsAdmin from './pages/MyEventsAdmin';
import MyClubEvents from './pages/MyClubEvents';
import SponsorshipRequest from './pages/SponsorshipRequest';
import SponsorshipRequestsAdmin from './pages/SponsorshipRequestsAdmin';
import ClubTasksAdmin from './pages/ClubTasksAdmin';
import ClubTasksMember from './pages/ClubTasksMember';
import ViewVolunteers from './pages/ViewVolunteers';

import MyFeedback from './pages/MyFeedback';

function App() {
  const userType = localStorage.getItem('userType');
  const token = localStorage.getItem('token');

  const RequireAuth = ({ children }) => {
    if (!token) return <Navigate to="/login" />;
    return children;
  };

  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          <Route
            path="/dashboard/student"
            element={
              <RequireAuth>
                {userType === 'student' ? <DashboardStudent /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/dashboard/admin"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <DashboardAdmin /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/club/create"
            element={
              <RequireAuth>
                {localStorage.getItem('userType') === 'club_admin' ? <ClubCreate /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/club/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/invitations"
            element={
              <RequireAuth>
                {userType === 'student' ? <Invitations /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/club/announcements/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubAnnouncementsManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/club/announcements"
            element={
              <RequireAuth>
                {userType === 'student' ? <ClubAnnouncementsView /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/club/activity/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubActivityManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/club/activity"
            element={
              <RequireAuth>
                {userType === 'student' ? <ClubActivityView /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/club/meetings/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubMeetingsManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/club/meetings"
            element={
              <RequireAuth>
                {userType === 'student' ? <ClubMeetingsView /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/club/polls/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubPollsManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/club/polls"
            element={
              <RequireAuth>
                {userType === 'student' ? <ClubPollsView /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/resource-upload"
            element={
              <RequireAuth>
                <ResourceUpload />
              </RequireAuth>
            }
          />
          <Route
            path="/workspace"
            element={
              <RequireAuth>
                <Workspace />
              </RequireAuth>
            }
          />

          <Route
            path="/club/events/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubEventsManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/club/events"
            element={
              <RequireAuth>
                {userType === 'student' ? <ClubEventsView /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/club/achievements/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubAchievementsManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/club/achievements"
            element={
              <RequireAuth>
                {userType === 'student' ? <ClubAchievementsView /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/feedback/submit"
            element={
              <RequireAuth>
                {userType === 'student' ? <FeedbackSubmit /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
          <Route
            path="/feedback/view"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <FeedbackView /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />

          <Route
            path="/club/contacts/manage"
            element={
              <RequireAuth>
                {userType === 'club_admin' ? <ClubContactsManage /> : <Navigate to="/login" />}
              </RequireAuth>
            }
          />
<Route
  path="/club/contacts"
  element={
    <RequireAuth>
      {userType === 'student' ? <ClubContactsView /> : <Navigate to="/login" />}
    </RequireAuth>
  }
/>

<Route
  path="/feedback/mine"
  element={
    <RequireAuth>
      {userType === 'student' ? <MyFeedback /> : <Navigate to="/login" />}
    </RequireAuth>
  }
/>

          <Route path="/events" element={<EventPortal />} />
          <Route path="/events/:eventId" element={<EventDetail />} />
          <Route path="/events/:eventId/gallery" element={<EventGallery />} />
          <Route path="/calendar" element={<EventCalendar />} />
          <Route path="/events/:eventId/attendees" element={<AttendeeList />} />
          <Route path="/events/mine" element={<MyEventsAdmin />} />
          <Route path="/my-club-events" element={<MyClubEvents />} />
          <Route path="/sponsorship-request/:eventId" element={<SponsorshipRequest />} />
          <Route path="/events/:eventId/sponsorship-requests" element={<SponsorshipRequestsAdmin />} />
          <Route path="/club/:clubId/tasks" element={<ClubTasksAdmin />} />
          <Route path="/my-tasks" element={<ClubTasksMember />} />

          <Route path="/clubs/:clubId/events/:eventId/volunteers" element={<RequireAuth><ViewVolunteers /></RequireAuth>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
