import React, { useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  return (
    <nav>
      {user && <span>Welcome, {user.name}!</span>}
      {user && <button onClick={logout}>Logout</button>}
    </nav>
  );
}
