import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Header.css';
import NotificationButton from './NotificationButton';
import { useLocation } from 'react-router-dom';

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const goToDashboard = () => {
    // Optional: Check localStorage/session/auth to redirect to correct dashboard
    const userType = localStorage.getItem('userType'); 
    if (userType === 'club_admin') navigate('/dashboard/admin');
    else navigate('/dashboard/student');
  };

  // Only show NotificationButton on dashboard routes
  const dashboardPaths = [
    '/dashboard/student',
    '/dashboard/admin'
  ];
  const isDashboard = dashboardPaths.some(path => location.pathname.startsWith(path));

  return (
    <header className="flex items-center p-4 bg-white shadow-md" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
        <img
          src="/images/logo.png"
          alt="ClubSphere Logo"
          className="logo"
          onClick={goToDashboard}
        />
        <span style={{
          fontWeight: 'bold',
          fontSize: '1.5rem',
          color: '#1a237e',
          fontFamily: 'Montserrat, Poppins, Arial, sans-serif',
          letterSpacing: '1px',
          textShadow: '1px 1px 2px #e0e0e0'
        }}>CampusOrbit</span>
      </div>
      {isDashboard && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '1rem', marginRight: '32px' }}>
          <NotificationButton />
          <button
            style={{
              background: '#f44336',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              padding: '8px 16px',
              cursor: 'pointer',
              fontWeight: 'bold',
              fontSize: '1rem'
            }}
            onClick={() => {
              localStorage.clear();
              window.location.href = '/login';
            }}
          >
            Logout
          </button>
        </div>
      )}
    </header>
  );
};

export default Header;
