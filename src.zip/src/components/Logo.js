import React from "react";

export default function Logo({ size = 80 }) {
  return (
    <img
      src="/images/logo.png"
      alt="CampusOrbit Logo"
      className="logo"
      style={{ width: size, height: "auto" }}
    />
  );
}
