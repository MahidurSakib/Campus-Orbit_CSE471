import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './FeedbackSubmit.css';

const FeedbackSubmit = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [message, setMessage] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  const submitFeedback = async (e) => {
    e.preventDefault();
    if (!message.trim()) {
      alert('Please enter a feedback message');
      return;
    }

    const res = await fetch(`/api/club/${selectedClub._id}/feedback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ message }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Feedback submitted');
      setMessage('');
    } else {
      alert(data.message || 'Failed to submit feedback');
    }
  };

  return (
    <>
      <Header />
      <main className="feedback-submit">
        <h1>Submit Feedback</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="feedback-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <form onSubmit={submitFeedback} className="feedback-form flex flex-col gap-4 max-w-md">
            <textarea
              rows={5}
              placeholder="Enter your feedback or suggestion here..."
              value={message}
              onChange={e => setMessage(e.target.value)}
              className="feedback-textarea"
              required
            />
            <button type="submit" className="submit-btn">
              Submit Feedback
            </button>
          </form>
        )}
      </main>
    </>
  );
};

export default FeedbackSubmit;
