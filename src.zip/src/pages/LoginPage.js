import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './LoginPage.css';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [userType, setUserType] = useState('student');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, userType }),
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('userType', data.userType);
      navigate(data.userType === 'club_admin' ? '/dashboard/admin' : '/dashboard/student');
    } else {
      alert(data.message);
    }
  };

  return (
    <>
      <Header />
      <main className="login-page">
        <form onSubmit={handleLogin} className="login-form">
          <h2>Login</h2>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            className="login-input"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
            className="login-input"
          />
          <select 
            value={userType}
            onChange={e => setUserType(e.target.value)}
            className="login-select"
          >
            <option value="student">Student</option>
            <option value="club_admin">Club Admin</option>
          </select>
          <button type="submit" className="login-btn">Login</button>
        </form>
      </main>
    </>
  );
};

export default LoginPage;
