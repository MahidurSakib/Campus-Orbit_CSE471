import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubPollsView.css';

const ClubPollsView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [polls, setPolls] = useState([]);
  const [loadingPolls, setLoadingPolls] = useState(false);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    setLoadingPolls(true);
    fetch(`/api/club/${selectedClub._id}/polls`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setPolls(data.polls);
        setLoadingPolls(false);
      });
  }, [selectedClub, token]);

  const votePoll = async (pollId, optionIndex) => {
    const res = await fetch(`/api/club/${selectedClub._id}/poll/${pollId}/vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ optionIndex }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Vote recorded');
      setPolls(prev =>
        prev.map(p =>
          p._id === pollId ? data.poll : p
        )
      );
    } else {
      alert(data.message || 'Failed to record vote');
    }
  };

  return (
    <>
      <Header />
      <main className="club-polls-view">
        <h1>Club Polls</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="poll-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setPolls([]);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {loadingPolls ? (
          <p>Loading polls...</p>
        ) : polls.length === 0 ? (
          <p>No polls available for this club.</p>
        ) : (
          polls.map(poll => {
            const userVotedOptionIndex = poll.options.findIndex(opt =>
              opt.votes.includes(localStorage.getItem('userId'))
            );

            return (
              <div key={poll._id} className="poll-item">
                <h3>{poll.question}</h3>
                <ul>
                  {poll.options.map((option, idx) => (
                    <li key={idx}>
                      <span>{option.text}</span>
                      <span>
                        {userVotedOptionIndex === -1 ? (
                          <button
                            onClick={() => votePoll(poll._id, idx)}
                            className="vote-btn"
                          >
                            Vote
                          </button>
                        ) : userVotedOptionIndex === idx ? (
                          <span className="your-vote">Your Vote</span>
                        ) : (
                          <span>Votes: {option.votes.length}</span>
                        )}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })
        )}
      </main>
    </>
  );
};

export default ClubPollsView;
