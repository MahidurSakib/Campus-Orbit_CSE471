import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubAchievementsView.css';

const ClubAchievementsView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [userAchievements, setUserAchievements] = useState([]);
  const [allAchievements, setAllAchievements] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setClubs(data.clubs); });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/achievements`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setUserAchievements(data.userAchievements);
          setAllAchievements(data.allAchievements);
        }
      });
  }, [selectedClub, token]);

  return (
    <>
      <Header />
      <main className="club-achievements">
        <h1>Club Achievements</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="club-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}
          </select>
        </div>

        {selectedClub && (
          <>
            <section className="mb-6">
              <h2>Your Achievements</h2>
              {userAchievements.length === 0 ? (
                <p>You have not earned any achievements yet.</p>
              ) : (
                <ul className="achievement-list">
                  {userAchievements.map(a => {
                    const achievement = allAchievements.find(ach => ach._id === a.achievement.toString());
                    return (
                      <li key={a._id} className="achievement-card">
                        {achievement && achievement.badgeUrl && <img src={achievement.badgeUrl} alt="badge" className="badge" />}
                        <div>
                          <p className="font-semibold">{achievement ? achievement.title : 'Achievement'}</p>
                          <p>{achievement ? achievement.description : ''}</p>
                          <p className="text-sm text-gray-500">Awarded on {new Date(a.awardedAt).toLocaleDateString()}</p>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>

            <section>
              <h2>All Club Achievements</h2>
              {allAchievements.length === 0 ? (
                <p>No achievements created by this club yet.</p>
              ) : (
                <ul className="achievement-list">
                  {allAchievements.map(a => (
                    <li key={a._id} className="achievement-card">
                      <p className="font-semibold">{a.title}</p>
                      <p>{a.description}</p>
                      {a.badgeUrl && <img src={a.badgeUrl} alt="badge" className="badge" />}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubAchievementsView;
