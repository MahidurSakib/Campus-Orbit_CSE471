import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './EventDetail.css';

const EventDetail = () => {
  const { eventId } = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [rsvpLoading, setRsvpLoading] = useState(false);
  const [rsvped, setRsvped] = useState(false);
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`/api/events/${eventId}`)
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setEvent(data.event);
          setRsvped(data.event.attendees?.includes(userId));
        }
        setLoading(false);
      });
  }, [eventId, userId]);

  const handleRSVP = async () => {
    setRsvpLoading(true);
    const res = await fetch(`/api/events/${eventId}/rsvp`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      setRsvped(true);
      alert('RSVP successful!');
    } else {
      alert(data.message || 'RSVP failed');
    }
    setRsvpLoading(false);
  };

  if (loading) return <p>Loading event...</p>;
  if (!event) return <p>Event not found.</p>;

  return (
    <>
      <Header />
      <main className="event-detail">
        <h1>{event.title}</h1>
        <p><b>Date:</b> {new Date(event.date).toLocaleString()}</p>
        <p><b>Location:</b> {event.location}</p>
        <p><b>Club:</b> {event.club?.name || 'Unknown'}</p>
        <p>{event.description}</p>
        <div className="event-actions">
          {!rsvped ? (
            <button onClick={handleRSVP} disabled={rsvpLoading} className="rsvp-btn">
              {rsvpLoading ? 'RSVPing...' : 'RSVP'}
            </button>
          ) : (
            <span className="rsvped">You have RSVP'd</span>
          )}
          <button onClick={() => navigate(`/events/${eventId}/gallery`)} className="gallery-btn">
            View Gallery
          </button>
        </div>

        {/* Social Media Share Buttons */}
        <div className="social-share">
          <h3>Share this event:</h3>
          <button
            className="share-btn facebook-btn"
            title="Share on Facebook"
            onClick={() => {
              const url = encodeURIComponent(window.location.href);
              window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
            }}
          >
            <img src="/images/facebook.png" alt="Facebook" width="32" height="32" />
          </button>
          <button
            className="share-btn whatsapp-btn"
            title="Share on WhatsApp"
            onClick={() => {
              const text = encodeURIComponent(`${event.title}\n${event.description}\n${window.location.href}`);
              window.open(`https://wa.me/?text=${text}`, '_blank');
            }}
          >
            <img src="/images/whatsapp.png" alt="WhatsApp" width="32" height="32" />
          </button>
          <button
            className="share-btn instagram-btn"
            title="Copy Link for Instagram"
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              alert('Event link copied! Paste it in your Instagram story or post.');
            }}
          >
            <img src="/images/instagram.png" alt="Instagram" width="32" height="32" />
          </button>
        </div>
      </main>
    </>
  );
};

export default EventDetail;
