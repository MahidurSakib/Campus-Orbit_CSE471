import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import Header from '../components/Header';
import './EventGallery.css';

const EventGallery = () => {
  const { eventId } = useParams();
  const location = useLocation();
  const [gallery, setGallery] = useState([]);
  const [loading, setLoading] = useState(true);
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const token = localStorage.getItem('token');
  const userType = localStorage.getItem('userType');
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    fetch(`/api/events/${eventId}/gallery`)
      .then(res => res.json())
      .then(data => {
        if (data.success) setGallery(data.gallery);
        setLoading(false);
      });
  }, [eventId]);
  const handleDeletePhoto = async (photoId) => {
    if (!window.confirm('Delete this photo?')) return;
    const res = await fetch(`/api/events/${eventId}/gallery/${photoId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    console.log('Delete response:', data);
    if (data.success) {
      setGallery(prev => prev.filter(photo => photo._id !== photoId));
      alert('Photo deleted');
    } else {
      alert(data.message || 'Failed to delete photo');
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`/api/events/${eventId}/gallery`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    });
    const data = await res.json();
    if (data.success) {
      setGallery(prev => [...prev, { uploader: userId, photoUrl: data.photoUrl }]);
      setFile(null);
      alert('Photo uploaded!');
    } else {
      alert(data.message || 'Upload failed');
    }
    setUploading(false);
  };

  return (
    <>
      <Header />
      <main className="event-gallery redesigned-gallery">
        <h1>Event Gallery</h1>
        <form onSubmit={handleUpload} className="upload-form">
          <input type="file" accept="image/*" onChange={e => setFile(e.target.files[0])} />
          <button type="submit" disabled={uploading || !file} className="upload-btn">
            {uploading ? 'Uploading...' : 'Upload Photo'}
          </button>
        </form>
        {loading ? (
          <p>Loading gallery...</p>
        ) : gallery.length === 0 ? (
          <p>No photos uploaded yet.</p>
        ) : (
          <div className="gallery-grid redesigned-grid">
            {gallery.map((photo) => (
              <div key={photo._id} className="gallery-item redesigned-item">
                <img src={photo.photoUrl} alt="Event" />
                {userType === 'club_admin' && location.state?.adminGallery && (
                  <button
                    className="delete-photo-btn"
                    onClick={() => handleDeletePhoto(photo._id)}
                  >
                    Delete
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </>
  );
};

export default EventGallery;
