import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubMeetingsManage.css';

const ClubMeetingsManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [meetings, setMeetings] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [invitedMembers, setInvitedMembers] = useState([]);
  const [allMembers, setAllMembers] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;

    fetch(`/api/club/${selectedClub._id}`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setAllMembers(data.club.members);
          setMeetings(data.club.meetings);
        }
      });
  }, [selectedClub, token]);

  const toggleInvite = (memberId) => {
    if (invitedMembers.includes(memberId)) {
      setInvitedMembers(invitedMembers.filter(id => id !== memberId));
    } else {
      setInvitedMembers([...invitedMembers, memberId]);
    }
  };

  const handleCreateMeeting = async (e) => {
    e.preventDefault();
    if (!title || !date) return alert('Title and Date are required');

    const res = await fetch(`/api/club/${selectedClub._id}/meeting`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ title, description, date, invitedMembers }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Meeting created');
      setTitle('');
      setDescription('');
      setDate('');
      setInvitedMembers([]);
      setMeetings(prev => [data.meeting, ...prev]);
    } else {
      alert(data.message || 'Failed to create meeting');
    }
  };

  return (
    <>
      <Header />
      <main className="club-meetings-manage">
        <h1>Manage Meetings</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="meeting-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setMeetings([]);
              setAllMembers([]);
              setInvitedMembers([]);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            <form onSubmit={handleCreateMeeting} className="meeting-form mt-6 flex flex-col gap-4 max-w-md">
              <input
                type="text"
                placeholder="Meeting Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="meeting-input"
                required
              />
              <textarea
                placeholder="Description (optional)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="meeting-textarea"
              />
              <input
                type="datetime-local"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="meeting-input"
                required
              />

              <div>
                <p className="font-semibold mb-2">Invite Members</p>
                <div className="invite-list">
                  {allMembers.map(member => (
                    <label key={member._id} className="member-invite">
                      <input
                        type="checkbox"
                        checked={invitedMembers.includes(member._id)}
                        onChange={() => toggleInvite(member._id)}
                      />
                      <span>{member.name} ({member.email})</span>
                    </label>
                  ))}
                </div>
              </div>

              <button type="submit" className="create-btn">
                Create Meeting
              </button>
            </form>

            <section className="mt-10">
              <h2>Upcoming Meetings</h2>
              {meetings.length === 0 ? (
                <p>No meetings scheduled.</p>
              ) : (
                <ul className="meeting-list">
                  {meetings.map((meeting) => (
                    <li key={meeting._id} className="meeting-card">
                      <h3>{meeting.title}</h3>
                      <p>{meeting.description}</p>
                      <p>Date: {new Date(meeting.date).toLocaleString()}</p>
                      <p>Invited: {meeting.invitedMembers.length} members</p>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubMeetingsManage;
