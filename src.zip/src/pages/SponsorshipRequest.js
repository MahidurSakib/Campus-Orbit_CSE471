import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './SponsorshipRequest.css';

const SponsorshipRequest = () => {
  const { eventId } = useParams();
  const [companyName, setCompanyName] = useState('');
  const [amount, setAmount] = useState('');
  const [coverLetter, setCoverLetter] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);
    try {
      const res = await fetch(`/api/sponsorship/${eventId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ companyName, amount, coverLetter }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccess(true);
        setTimeout(() => navigate('/my-club-events'), 1500);
      } else {
        setError(data.message || 'Failed to submit request');
      }
    } catch (err) {
      setError('Failed to submit request');
    }
    setLoading(false);
  };

  return (
    <>
      <Header />
      <main className="sponsorship-request">
        <h1>Request Sponsorship</h1>
        <form onSubmit={handleSubmit} className="sponsorship-form">
          <label>
            Company Name
            <input
              type="text"
              value={companyName}
              onChange={e => setCompanyName(e.target.value)}
              required
            />
          </label>
          <label>
            Amount
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              required
              min="1"
            />
          </label>
          <label>
            Cover Letter
            <textarea
              value={coverLetter}
              onChange={e => setCoverLetter(e.target.value)}
              required
              rows={5}
            />
          </label>
          <button type="submit" disabled={loading}>
            {loading ? 'Submitting...' : 'Submit Request'}
          </button>
          {error && <p className="error-msg">{error}</p>}
          {success && <p className="success-msg">Request submitted!</p>}
        </form>
      </main>
    </>
  );
};

export default SponsorshipRequest;
