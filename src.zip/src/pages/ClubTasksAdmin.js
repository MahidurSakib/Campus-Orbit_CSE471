import React, { useEffect, useState, useContext } from 'react';
import Header from '../components/Header';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';
import './ClubTasksAdmin.css';

const ClubTasksAdmin = () => {
  const { user } = useContext(AuthContext) || {};
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState('');
  const [members, setMembers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [description, setDescription] = useState('');
  const [selectedMember, setSelectedMember] = useState('');
  const [loading, setLoading] = useState(false);
  const [memberError, setMemberError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch clubs created by admin
    fetch('/api/club/myclubs', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    })
      .then(res => res.json())
      .then(data => {
        setClubs(data.clubs || []);
      });
  }, []);

  useEffect(() => {
    if (!selectedClub) return;
    setLoading(true);
    setMemberError('');
    // Fetch club members
    fetch(`/api/club/${selectedClub}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.club) {
          setMembers(data.club.members);
          if (!data.club.members || data.club.members.length === 0) {
            setMemberError('No members found in this club.');
          }
        } else {
          setMemberError(data.message || 'Failed to fetch members.');
        }
      })
      .catch(err => {
        setMemberError('Error fetching members: ' + err.message);
      });
    // Fetch club tasks
    fetch(`/api/tasks/club/${selectedClub}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    })
      .then(res => res.json())
      .then(data => {
        setTasks(data.tasks || []);
        setLoading(false);
      });
  }, [selectedClub]);

  const handleAssign = async e => {
    e.preventDefault();
    if (!selectedMember || !description || !selectedClub) return;
    const res = await fetch(`/api/tasks/assign/${selectedClub}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` },
      body: JSON.stringify({ memberId: selectedMember, description }),
    });
    const data = await res.json();
    if (data.success) {
      setTasks(prev => [data.task, ...prev]);
      setDescription('');
      setSelectedMember('');
      alert('Task assigned!');
    } else {
      alert(data.message || 'Failed to assign task');
    }
  };

  const handleComplete = async taskId => {
    const res = await fetch(`/api/tasks/complete/${taskId}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    const data = await res.json();
    if (data.success) {
      setTasks(prev => prev.map(t => t._id === taskId ? data.task : t));
      alert('Task marked complete!');
    } else {
      alert(data.message || 'Failed to mark complete');
    }
  };

  return (
    <>
      <Header />
      <main className="club-tasks-admin">
        <h1>Assign & Track Member Tasks</h1>
        <form onSubmit={handleAssign} className="task-form">
          <select value={selectedClub} onChange={e => setSelectedClub(e.target.value)} required>
            <option value="">Select Club</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
          <select value={selectedMember} onChange={e => setSelectedMember(e.target.value)} required disabled={!selectedClub}>
            <option value="">Select Member</option>
            {members.map(m => (
              <option key={m._id} value={m._id}>{m.name} ({m.email})</option>
            ))}
          </select>
          <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="Task description" required disabled={!selectedClub || !selectedMember} />
          <button type="submit" disabled={!selectedClub || !selectedMember || !description}>Assign Task</button>
        </form>
        {memberError && <p style={{ color: 'red', marginBottom: '1rem' }}>{memberError}</p>}
        <h2>All Tasks</h2>
        {loading ? <p>Loading tasks...</p> : !selectedClub ? <p>Select a club to view tasks.</p> : tasks.length === 0 ? <p>No tasks assigned yet.</p> : (
          <ul>
            {tasks.map(task => (
              <li key={task._id}>
                <p><b>Member:</b> {task.assignedTo?.name} ({task.assignedTo?.email})</p>
                <p><b>Description:</b> {task.description}</p>
                <p><b>Progress:</b> {task.progress || 'No update yet.'}</p>
                <p><b>Status:</b> <span style={{ color: task.status === 'completed' ? 'green' : task.status === 'in-progress' ? 'orange' : '#888' }}>{task.status.charAt(0).toUpperCase() + task.status.slice(1)}</span></p>
                {task.status !== 'completed' && (
                  <button onClick={() => handleComplete(task._id)}>Mark Complete</button>
                )}
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
};

export default ClubTasksAdmin;
