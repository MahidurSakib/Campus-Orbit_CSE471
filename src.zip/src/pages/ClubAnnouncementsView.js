import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubAnnouncementsView.css';

const ClubAnnouncementsView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [announcements, setAnnouncements] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchJoinedClubs = async () => {
      const res = await fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (data.success) setClubs(data.clubs);
    };

    fetchJoinedClubs();
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/announcements`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setAnnouncements(data.announcements);
      });
  }, [selectedClub, token]);

  return (
    <>
      <Header />
      <main className="club-announcements-view">
        <h1>Club Announcements</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="announcement-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setAnnouncements([]);
            }}
          >
            <option value="">-- Select a club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            {announcements.length === 0 ? (
              <p>No announcements for this club.</p>
            ) : (
              <ul className="announcement-list mt-6 space-y-4">
                {announcements.map((ann, i) => (
                  <li key={i}>
                    <h3>{ann.title}</h3>
                    <p>{ann.content}</p>
                    <p className="text-sm text-gray-500">{new Date(ann.date).toLocaleString()}</p>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </main>
    </>
  );
};

export default ClubAnnouncementsView;
