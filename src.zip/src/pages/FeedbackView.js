import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './FeedbackView.css';

const FeedbackView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [feedbacks, setFeedbacks] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/feedbacks`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setFeedbacks(data.feedbacks);
      });
  }, [selectedClub, token]);

  return (
    <>
      <Header />
      <main className="feedback-view">
        <h1>Feedback and Suggestions</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="feedback-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            {feedbacks.length === 0 ? (
              <p>No feedback received yet.</p>
            ) : (
              <ul className="feedback-list">
                {feedbacks.map(feed => (
                  <li key={feed._id}>
                    <p className="sender">{feed.sender.name} ({feed.sender.email}):</p>
                    <p>{feed.message}</p>
                    <p className="date">{new Date(feed.createdAt).toLocaleString()}</p>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </main>
    </>
  );
};

export default FeedbackView;
