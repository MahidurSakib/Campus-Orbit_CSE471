import React from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './DashboardStudent.css';

const DashboardStudent = () => {
  const navigate = useNavigate();

  return (
    <>
      <Header />
      <main className="dashboard-student">
        <h1>Student Dashboard</h1>
        <p>Welcome! View your club details and announcements here.</p>

        <div className="button-group">
          <button
            onClick={() => navigate('/invitations')}
            className="dashboard-btn"
          >
            View Club Invitations
          </button>

          <button className="btn" onClick={() => navigate('/feedback/mine')}>
  View Feedback
</button>

          <button
            onClick={() => navigate('/club/announcements')}
            className="dashboard-btn"
          >
            View Club Announcements
          </button>

          <button
            onClick={() => navigate('/my-tasks')}
            className="dashboard-btn"
          >
            My Assigned Tasks
          </button>

          <button
            onClick={() => navigate('/club/activity')}
            className="dashboard-btn"
          >
            View Activity Log
          </button>

          <button
            onClick={() => navigate('/club/meetings')}
            className="dashboard-btn"
          >
            View Meetings & Attendance
          </button>

          <button
            onClick={() => navigate('/club/polls')}
            className="dashboard-btn"
          >
            View Polls
          </button>

          <button
            onClick={() => navigate('/workspace')}
            className="dashboard-btn"
          >
            Workspace
          </button>

          <button
            onClick={() => navigate('/club/events')}
            className="dashboard-btn"
          >
            Volunteer for Events
          </button>

          <button
            onClick={() => navigate('/club/achievements')}
            className="dashboard-btn"
          >
            View Achievements
          </button>

          <button
            onClick={() => navigate('/feedback/submit')}
            className="dashboard-btn"
          >
            Submit Feedback
          </button>

          <button
            onClick={() => navigate('/club/contacts')}
            className="dashboard-btn"
          >
            View Contacts
          </button>
            <button
              onClick={() => navigate('/events')}
              className="dashboard-btn"
            >
              Event Portal
            </button>
            <button
              onClick={() => navigate('/my-club-events')}
              className="dashboard-btn"
            >
              My Club Events
            </button>
        </div>
      </main>
    </>
  );
};

export default DashboardStudent;
