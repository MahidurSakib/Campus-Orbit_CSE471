import React from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './HomePage.css';

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <>
      <Header />
      <main className="homepage">
        <h1>Welcome to CampusOrbit</h1>
        <p>
          Your all-in-one student engagement platform — connect, explore, and thrive on campus.
        </p>
        <div className="btn-group">
          <button onClick={() => navigate('/login')} className="login-btn">
            Login
          </button>
          <button onClick={() => navigate('/register')} className="register-btn">
            Register
          </button>
        </div>
      </main>
    </>
  );
};

export default HomePage;
