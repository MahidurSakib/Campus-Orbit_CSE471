import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './MyEventsAdmin.css';

const MyEventsAdmin = () => {
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', date: '', location: '', clubId: '' });
  const [clubs, setClubs] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editForm, setEditForm] = useState({ title: '', description: '', date: '', location: '' });
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setClubs(data.clubs); });
  }, [token]);

  useEffect(() => {
    fetch('/api/events/mine', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setEvents(data.events);
        setLoading(false);
      });
  }, [token]);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCreate = async e => {
    e.preventDefault();
    const res = await fetch('/api/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    if (data.success) {
      setEvents(prev => [data.event, ...prev]);
      setShowForm(false);
      setForm({ title: '', description: '', date: '', location: '', clubId: '' });
      alert('Event created!');
    } else {
      alert(data.message || 'Failed to create event');
    }
  };

  const handleDelete = async eventId => {
    if (!window.confirm('Delete this event?')) return;
    const res = await fetch(`/api/events/${eventId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      setEvents(prev => prev.filter(e => e._id !== eventId));
      alert('Event deleted');
    } else {
      alert(data.message || 'Failed to delete event');
    }
  };

  const handleEdit = async (eventId, updates) => {
    const res = await fetch(`/api/events/${eventId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(updates),
    });
    const data = await res.json();
    if (data.success) {
      setEvents(prev => prev.map(e => e._id === eventId ? data.event : e));
      alert('Event updated');
    } else {
      alert(data.message || 'Failed to update event');
    }
  };

  const viewAttendees = eventId => {
    navigate(`/events/${eventId}/attendees`);
  };

  return (
    <>
      <Header />
      <main className="my-events-admin">
        <h1>My Created Events</h1>
        <button onClick={() => setShowForm(!showForm)} className="create-btn">
          {showForm ? 'Cancel' : 'Create New Event'}
        </button>
        {showForm && (
          <form onSubmit={handleCreate} className="event-form">
            <input name="title" value={form.title} onChange={handleChange} placeholder="Title" required />
            <input name="date" type="datetime-local" value={form.date} onChange={handleChange} required />
            <input name="location" value={form.location} onChange={handleChange} placeholder="Location" required />
            <select name="clubId" value={form.clubId} onChange={handleChange} required>
              <option value="">Select Club</option>
              {clubs.map(club => <option key={club._id} value={club._id}>{club.name}</option>)}
            </select>
            <textarea name="description" value={form.description} onChange={handleChange} placeholder="Description" rows={3} />
            <button type="submit" className="submit-btn">Create</button>
          </form>
        )}
        {loading ? (
          <p>Loading events...</p>
        ) : events.length === 0 ? (
          <p>No events created yet.</p>
        ) : (
          <ul className="event-list">
            {events.map(event => (
              <li key={event._id} className="event-card">
                <div>
                  <h2>{event.title}</h2>
                  <p><b>Date:</b> {new Date(event.date).toLocaleString()}</p>
                  <p><b>Location:</b> {event.location}</p>
                  <p>{event.description}</p>
                  <div className="event-actions-row event-actions-row-top">
                    <button onClick={() => viewAttendees(event._id)} className="event-action-btn attendees-btn">View Attendees</button>
                    <button onClick={() => navigate(`/events/${event._id}/gallery`, { state: { adminGallery: true } })} className="event-action-btn gallery-btn">Gallery</button>
                    <button onClick={() => navigate(`/events/${event._id}/sponsorship-requests`)} className="event-action-btn sponsorship-btn">Sponsorship Requests</button>
                  </div>
                  <div className="event-actions-row event-actions-row-bottom">
                    <button onClick={() => handleDelete(event._id)} className="event-action-btn delete-btn">Delete</button>
                    <button onClick={() => {
                      setEditId(event._id);
                      setEditForm({
                        title: event.title,
                        description: event.description,
                        date: event.date ? new Date(event.date).toISOString().slice(0,16) : '',
                        location: event.location
                      });
                    }} className="event-action-btn edit-btn">Edit</button>
                  </div>
                </div>
                {editId === event._id && (
                  <form
                    onSubmit={e => {
                      e.preventDefault();
                      handleEdit(event._id, editForm);
                      setEditId(null);
                    }}
                    className="event-form edit-form"
                  >
                    <input name="title" value={editForm.title} onChange={e => setEditForm({ ...editForm, title: e.target.value })} placeholder="Title" required />
                    <input name="date" type="datetime-local" value={editForm.date} onChange={e => setEditForm({ ...editForm, date: e.target.value })} required />
                    <input name="location" value={editForm.location} onChange={e => setEditForm({ ...editForm, location: e.target.value })} placeholder="Location" required />
                    <textarea name="description" value={editForm.description} onChange={e => setEditForm({ ...editForm, description: e.target.value })} placeholder="Description" rows={2} />
                    <button type="submit" className="submit-btn">Save</button>
                    <button type="button" className="cancel-btn" onClick={() => setEditId(null)}>Cancel</button>
                  </form>
                )}
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
};

export default MyEventsAdmin;
