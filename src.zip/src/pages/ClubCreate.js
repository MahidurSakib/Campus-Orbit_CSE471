import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './ClubCreate.css';

const ClubCreate = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);

    const token = localStorage.getItem('token');

    const res = await fetch('/api/club/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ name, description }),
    });

    const data = await res.json();
    setLoading(false);

    if (data.success) {
      alert('Club created successfully!');
      navigate('/dashboard/admin');
    } else {
      alert(data.message || 'Club creation failed');
    }
  };

  return (
    <>
      <Header />
      <main className="club-create">
        <h1>Create New Club</h1>
        <form onSubmit={handleCreate} className="club-create-form">
          <input
            type="text"
            placeholder="Club Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="club-input"
          />
          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="club-textarea"
          />
          <button type="submit" disabled={loading} className="create-btn">
            {loading ? 'Creating...' : 'Create Club'}
          </button>
        </form>
      </main>
    </>
  );
};

export default ClubCreate;
