import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ResourceUpload.css';

const ResourceUpload = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [resourceType, setResourceType] = useState('file');
  const [file, setFile] = useState(null);
  const [linkUrl, setLinkUrl] = useState('');
  const [title, setTitle] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedClub) return alert('Select a club');
    if (!title.trim()) return alert('Title is required');
    if (resourceType === 'file' && !file) return alert('Select a file');
    if (resourceType === 'link' && !linkUrl.trim()) return alert('Enter a link URL');

    const formData = new FormData();
    formData.append('title', title);
    formData.append('type', resourceType);
    if (resourceType === 'file') {
      formData.append('file', file);
    } else {
      formData.append('linkUrl', linkUrl);
    }

    const res = await fetch(`/api/club/${selectedClub._id}/resource`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    });
    const data = await res.json();
    if (data.success) {
      alert('Resource uploaded');
      setTitle('');
      setFile(null);
      setLinkUrl('');
    } else {
      alert(data.message || 'Failed to upload resource');
    }
  };

  return (
    <>
      <Header />
      <main className="resource-upload">
        <h1>Upload Resource</h1>
        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="resource-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map((club) => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        <div className="resource-type-selector">
          <label>
            <input
              type="radio"
              name="resourceType"
              value="file"
              checked={resourceType === 'file'}
              onChange={() => setResourceType('file')}
            />
            {' '}File
          </label>
          <label>
            <input
              type="radio"
              name="resourceType"
              value="link"
              checked={resourceType === 'link'}
              onChange={() => setResourceType('link')}
            />
            {' '}Link
          </label>
        </div>

        <form onSubmit={handleSubmit} encType="multipart/form-data" className="resource-form">
          <input
            type="text"
            placeholder="Resource Title"
            value={title}
            onChange={e => setTitle(e.target.value)}
            className="resource-input"
            required
          />

          {resourceType === 'file' && (
            <input
              type="file"
              onChange={handleFileChange}
              className="resource-input"
            />
          )}

          {resourceType === 'link' && (
            <input
              type="url"
              placeholder="Link URL"
              value={linkUrl}
              onChange={e => setLinkUrl(e.target.value)}
              className="resource-input"
            />
          )}

          <button type="submit" className="upload-btn">Upload Resource</button>
        </form>
      </main>
    </>
  );
};

export default ResourceUpload;
