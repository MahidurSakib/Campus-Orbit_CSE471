import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubActivityManage.css';

const ClubActivityManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [activityLog, setActivityLog] = useState([]);
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/activity`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setActivityLog(data.activityLog);
      });
  }, [selectedClub, token]);

  const handlePhotoUpload = (e) => {
    const files = e.target.files;
    const fileReaders = [];
    let isCancel = false;
    const images = [];

    if (files.length === 0) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      fileReaders.push(reader);

      reader.onload = (e) => {
        if (isCancel) return;
        images.push(e.target.result);
        if (images.length === files.length) {
          setPhotos(images);
        }
      };
      reader.readAsDataURL(file);
    });

    return () => {
      isCancel = true;
      fileReaders.forEach(fr => { if (fr.readyState === 1) fr.abort(); });
    };
  };

  const handleAddActivity = async (e) => {
    e.preventDefault();
    if (!description) return alert('Description is required');

    const res = await fetch(`/api/club/${selectedClub._id}/activity`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ description, photos }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Activity added');
      setDescription('');
      setPhotos([]);
      setActivityLog(prev => [data.activity, ...prev]);
    } else {
      alert(data.message || 'Failed to add activity');
    }
  };

  return (
    <>
      <Header />
      <main className="club-activity">
        <h1>Manage Activity Log</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="club-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setActivityLog([]);
            }}
          >
            <option value="">-- Select a club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            <form onSubmit={handleAddActivity} className="activity-form">
              <textarea
                placeholder="Activity description"
                value={description}
                onChange={e => setDescription(e.target.value)}
                rows="4"
                className="club-textarea"
                required
              />
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoUpload}
                className="club-input"
              />
              <button type="submit" className="add-btn">Add Activity</button>
            </form>

            <section className="mt-8">
              <h2>Activity Log</h2>
              {activityLog.length === 0 ? (
                <p>No activities recorded yet.</p>
              ) : (
                <ul className="activity-list">
                  {activityLog.map((activity, i) => (
                    <li key={i} className="activity-card">
                      <p>{activity.description}</p>
                      <div className="photos">
                        {activity.photos && activity.photos.map((photo, idx) => (
                          <img
                            key={idx}
                            src={photo}
                            alt="Activity"
                            className="photo-thumbnail"
                          />
                        ))}
                      </div>
                      <p className="timestamp">{new Date(activity.date).toLocaleString()}</p>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubActivityManage;
