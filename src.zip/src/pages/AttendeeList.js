import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Header from '../components/Header';
import './AttendeeList.css';

const AttendeeList = () => {
  const { eventId } = useParams();
  const [attendees, setAttendees] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch(`/api/events/${eventId}/attendees`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) setAttendees(data.attendees);
        setLoading(false);
      });
  }, [eventId, token]);

  return (
    <>
      <Header />
      <main className="attendee-list-page">
        <h1>Attendee List</h1>
        {loading ? (
          <p>Loading attendees...</p>
        ) : attendees.length === 0 ? (
          <p>No attendees yet.</p>
        ) : (
          <ul className="attendee-list">
            {attendees.map(a => (
              <li key={a._id} className="attendee-card">
                <span className="attendee-name">{a.name}</span>
                <span className="attendee-email">{a.email}</span>
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
};

export default AttendeeList;
