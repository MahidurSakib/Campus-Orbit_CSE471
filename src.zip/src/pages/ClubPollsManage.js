import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubPollsManage.css';

const ClubPollsManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [polls, setPolls] = useState([]);

  const [newQuestion, setNewQuestion] = useState('');
  const [newOptions, setNewOptions] = useState(['', '']); // start with 2 options

  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;

    fetch(`/api/club/${selectedClub._id}/polls`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setPolls(data.polls);
      });
  }, [selectedClub, token]);

  const addOption = () => {
    setNewOptions([...newOptions, '']);
  };

  const removeOption = (index) => {
    setNewOptions(newOptions.filter((_, i) => i !== index));
  };

  const updateOption = (index, value) => {
    const updated = [...newOptions];
    updated[index] = value;
    setNewOptions(updated);
  };

  const createPoll = async () => {
    if (!newQuestion.trim()) return alert('Question is required');
    if (newOptions.some(opt => !opt.trim())) return alert('All options must be filled');

    const res = await fetch(`/api/club/${selectedClub._id}/poll`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ question: newQuestion, options: newOptions }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Poll created');
      setNewQuestion('');
      setNewOptions(['', '']);
      setPolls(prev => [...prev, data.poll]);
    } else {
      alert(data.message || 'Failed to create poll');
    }
  };

  const deletePoll = async (pollId) => {
    if (!window.confirm('Delete this poll?')) return;

    const res = await fetch(`/api/club/${selectedClub._id}/poll/${pollId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert('Poll deleted');
      setPolls(polls.filter(p => p._id !== pollId));
    } else {
      alert(data.message || 'Failed to delete poll');
    }
  };

  return (
    <>
      <Header />
      <main className="club-polls-manage">
        <h1>Manage Polls</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="poll-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setPolls([]);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            <section className="create-poll-section mt-6 max-w-md">
              <h2>Create New Poll</h2>

              <input
                type="text"
                placeholder="Poll Question"
                value={newQuestion}
                onChange={e => setNewQuestion(e.target.value)}
                className="poll-input"
              />

              {newOptions.map((option, idx) => (
                <div key={idx} className="option-row flex items-center mb-2 gap-2">
                  <input
                    type="text"
                    value={option}
                    onChange={(e) => updateOption(idx, e.target.value)}
                    className="poll-input flex-grow"
                    placeholder={`Option ${idx + 1}`}
                  />
                  {newOptions.length > 2 && (
                    <button
                      onClick={() => removeOption(idx)}
                      className="remove-option-btn text-red-600 font-bold"
                      type="button"
                    >
                      &times;
                    </button>
                  )}
                </div>
              ))}

              <button onClick={addOption} type="button" className="add-option-btn text-indigo-600 mb-4">
                + Add Option
              </button>

              <button onClick={createPoll} className="add-poll-btn">
                Create Poll
              </button>
            </section>

            <section className="mt-10">
              <h2>Existing Polls</h2>

              {polls.length === 0 ? (
                <p>No polls created yet.</p>
              ) : (
                polls.map(poll => (
                  <div key={poll._id} className="poll-list">
                    <h3>{poll.question}</h3>
                    <ul>
                      {poll.options.map((opt, i) => (
                        <li key={i} className="flex justify-between mb-1">
                          <span>{opt.text}</span>
                          <span>Votes: {opt.votes.length}</span>
                        </li>
                      ))}
                    </ul>
                    <button
                      onClick={() => deletePoll(poll._id)}
                      className="delete-poll-btn"
                    >
                      Delete Poll
                    </button>
                  </div>
                ))
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubPollsManage;
