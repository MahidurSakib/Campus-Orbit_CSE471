import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubContactsView.css';

const ClubContactsView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [contacts, setContacts] = useState([]);

  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setClubs(data.clubs); });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/contacts`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setContacts(data.contacts);
      });
  }, [selectedClub, token]);

  return (
    <>
      <Header />
      <main className="club-contacts">
        <h1>Club Contact Directory</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="club-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(c => (
              <option key={c._id} value={c._id}>{c.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            {contacts.length === 0 ? (
              <p>No contacts available.</p>
            ) : (
              <ul className="contact-list">
                {contacts.map(contact => (
                  <li key={contact._id} className="contact-card">
                    <p className="font-semibold">{contact.name}</p>
                    <p>{contact.roleInClub}</p>
                    <p>{contact.contactEmail}</p>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </main>
    </>
  );
};

export default ClubContactsView;
