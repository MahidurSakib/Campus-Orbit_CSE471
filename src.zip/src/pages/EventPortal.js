import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './EventPortal.css';

const EventPortal = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filteredEvents, setFilteredEvents] = useState([]);
  const [club, setClub] = useState('');
  const [date, setDate] = useState('');
  const [clubs, setClubs] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/events')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setEvents(data.events);
          setFilteredEvents(data.events);
        }
        setLoading(false);
      });
    fetch('/api/club')
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, []);

  useEffect(() => {
    let filtered = events;
    if (club) filtered = filtered.filter(e => e.club?._id === club);
    if (date) {
      filtered = filtered.filter(e => {
        const eventDate = new Date(e.date);
        const filterDate = new Date(date);
        return (
          eventDate.getFullYear() === filterDate.getFullYear() &&
          eventDate.getMonth() === filterDate.getMonth() &&
          eventDate.getDate() === filterDate.getDate()
        );
      });
    }
    setFilteredEvents(filtered);
  }, [club, date, events]);

  const [showFilter, setShowFilter] = useState(false);

  return (
    <>
      <Header />
      <main className="event-portal">
        <div className="event-portal-icons">
          <img
            src="/images/calendar.png"
            alt="Calendar"
            className="calendar-icon"
            style={{ position: 'absolute', top: '32px', right: '120px', width: '40px', height: '40px', cursor: 'pointer' }}
            onClick={() => navigate('/calendar')}
          />
          <img
            src="/images/filter.png"
            alt="Filter"
            className="filter-icon"
            style={{ position: 'absolute', top: '90px', right: '120px', width: '40px', height: '40px', cursor: 'pointer' }}
            onClick={() => setShowFilter(true)}
          />
        </div>
        <h1>All Main Events</h1>
        {loading ? (
          <p>Loading events...</p>
        ) : filteredEvents.length === 0 ? (
          <p>No events found.</p>
        ) : (
          <ul className="event-list">
            {filteredEvents.map(event => (
              <li key={event._id} className="event-card">
                <div>
                  <h2>{event.title}</h2>
                  <p><b>Date:</b> {new Date(event.date).toLocaleString()}</p>
                  <p><b>Location:</b> {event.location}</p>
                  <p><b>Club:</b> {event.club?.name || 'Unknown'}</p>
                  <p>{event.description}</p>
                </div>
                <button onClick={() => navigate(`/events/${event._id}`)} className="view-btn">
                  View Event
                </button>
              </li>
            ))}
          </ul>
        )}

        {/* Filter Modal with controls */}
        {showFilter && (
          <div className="filter-modal" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
            <div style={{ background: '#fff', padding: '2.5rem 2.5rem 2rem 2.5rem', borderRadius: '12px', minWidth: '320px', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }}>
              <h2>Filter Events</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', marginBottom: '2rem' }}>
                <label>
                  Date:
                  <input type="date" value={date} onChange={e => setDate(e.target.value)} />
                </label>
                <label>
                  Club:
                  <select value={club} onChange={e => setClub(e.target.value)}>
                    <option value="">All Clubs</option>
                    {Array.isArray(clubs) && clubs.length > 0 && clubs.map(c => (
                      <option key={c._id} value={c._id}>{c.name}</option>
                    ))}
                  </select>
                </label>
              </div>
              <button onClick={() => setShowFilter(false)} style={{ marginTop: '1rem', padding: '0.5rem 1.2rem', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Close</button>
            </div>
          </div>
        )}
      </main>
    </>
  );
};

export default EventPortal;
