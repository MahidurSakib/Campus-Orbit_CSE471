import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubAnnouncementsManage.css';

const ClubAnnouncementsManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [announcements, setAnnouncements] = useState([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/announcements`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setAnnouncements(data.announcements);
      });
  }, [selectedClub, token]);

  const handleAddAnnouncement = async (e) => {
    e.preventDefault();
    if (!title || !content) return alert('Title and content are required');
    const res = await fetch(`/api/club/${selectedClub._id}/announcement`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ title, content }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Announcement added');
      setTitle('');
      setContent('');
      setAnnouncements(prev => [data.announcement, ...prev]);
    } else {
      alert(data.message || 'Failed to add announcement');
    }
  };

  return (
    <>
      <Header />
      <main className="club-announcements">
        <h1>Manage Announcements</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="announcement-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setAnnouncements([]);
            }}
          >
            <option value="">-- Select a club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            <form onSubmit={handleAddAnnouncement} className="announcement-form">
              <input
                type="text"
                placeholder="Announcement Title"
                value={title}
                onChange={e => setTitle(e.target.value)}
                required
                className="announcement-input"
              />
              <textarea
                placeholder="Announcement Content"
                value={content}
                onChange={e => setContent(e.target.value)}
                rows="4"
                required
                className="announcement-textarea"
              />
              <button type="submit" className="add-btn">
                Add Announcement
              </button>
            </form>

            <section className="mt-8">
              <h2>Existing Announcements</h2>
              {announcements.length === 0 ? (
                <p>No announcements yet.</p>
              ) : (
                <div className="announcement-list">
                  {announcements.map((ann, i) => (
                    <div key={i} className="announcement-card">
                      <h3>{ann.title}</h3>
                      <p>{ann.content}</p>
                      <p className="text-sm">{new Date(ann.date).toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubAnnouncementsManage;
