import React, { useEffect, useState, useContext } from 'react';
import Header from '../components/Header';
import { AuthContext } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import './MyClubEvents.css';

const MyClubEvents = () => {
  const { user } = useContext(AuthContext) || {};
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [myRequests, setMyRequests] = useState([]);
  const [showRequests, setShowRequests] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/events/my-club-events', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    })
      .then(res => res.json())
      .then(data => {
        setEvents(data.events || []);
        setLoading(false);
      });
    fetch('/api/sponsorship/my-requests', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    })
      .then(res => res.json())
      .then(data => {
        setMyRequests(data.requests || []);
      });
  }, []);

  return (
    <>
      <Header />
      <main className="my-club-events">
        <h1>My Club Events</h1>
        <button className="see-requests-btn" onClick={() => setShowRequests(true)} style={{marginBottom: '1.5rem', padding: '0.5rem 1.2rem', background: '#17a2b8', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer'}}>
          See Requests
        </button>
        {loading ? (
          <p>Loading events...</p>
        ) : events.length === 0 ? (
          <p>No events found for your clubs.</p>
        ) : (
          <div className="club-events-list">
            {events.map(event => (
              <div key={event._id} className="club-event-card">
                <h3>{event.title}</h3>
                <p><b>Date:</b> {new Date(event.date).toLocaleDateString()}</p>
                <p><b>Club:</b> {event.club?.name}</p>
                <p>{event.description}</p>
                <button
                  className="sponsorship-btn"
                  onClick={() => navigate(`/sponsorship-request/${event._id}`)}
                >
                  Request Sponsorship
                </button>
              </div>
            ))}
          </div>
        )}
        {/* Modal for requests */}
        {showRequests && (
          <div className="requests-modal" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
            <div style={{ background: '#fff', padding: '2.5rem 2.5rem 2rem 2.5rem', borderRadius: '12px', minWidth: '320px', boxShadow: '0 2px 8px rgba(0,0,0,0.15)', maxHeight: '80vh', overflowY: 'auto' }}>
              <h2>My Sponsorship Requests</h2>
              {myRequests.length === 0 ? (
                <p>No sponsorship requests submitted.</p>
              ) : (
                <ul style={{ listStyle: 'none', padding: 0 }}>
                  {myRequests.map(req => (
                    <li key={req._id} style={{ marginBottom: '1.2rem', borderBottom: '1px solid #eee', paddingBottom: '1rem' }}>
                      <p><b>Event:</b> {req.event?.title || 'Unknown Event'}</p>
                      <p><b>Company:</b> {req.companyName}</p>
                      <p><b>Amount:</b> {req.amount}</p>
                      <p><b>Status:</b> <span style={{ color: req.status === 'approved' ? 'green' : req.status === 'rejected' ? 'red' : '#888' }}>{req.status ? req.status.charAt(0).toUpperCase() + req.status.slice(1) : 'Pending'}</span></p>
                      <p><b>Submitted:</b> {new Date(req.createdAt).toLocaleString()}</p>
                    </li>
                  ))}
                </ul>
              )}
              <button onClick={() => setShowRequests(false)} style={{ marginTop: '1rem', padding: '0.5rem 1.2rem', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Close</button>
            </div>
          </div>
        )}
      </main>
    </>
  );
};

export default MyClubEvents;
