import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Header from '../components/Header';
import './SponsorshipRequestsAdmin.css';

const SponsorshipRequestsAdmin = () => {
  const { eventId } = useParams();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch(`/api/sponsorship/event/${eventId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) setRequests(data.requests);
        else setError(data.message || 'Failed to fetch requests');
        setLoading(false);
      });
  }, [eventId, token]);

  const handleStatus = async (requestId, status) => {
    const res = await fetch(`/api/sponsorship/${requestId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (data.success) {
      setRequests(prev => prev.map(r => r._id === requestId ? { ...r, status } : r));
    } else {
      alert(data.message || 'Failed to update status');
    }
  };

  return (
    <>
      <Header />
      <main className="sponsorship-requests-admin">
        <h1>Sponsorship Requests</h1>
        {loading ? (
          <p>Loading...</p>
        ) : error ? (
          <p className="error-msg">{error}</p>
        ) : requests.length === 0 ? (
          <p>No sponsorship requests for this event.</p>
        ) : (
          <ul className="requests-list">
            {requests.map(req => (
              <li key={req._id} className="request-card">
                <p><b>Company:</b> {req.companyName}</p>
                <p><b>Amount:</b> {req.amount}</p>
                <p><b>Cover Letter:</b> {req.coverLetter}</p>
                <p><b>Member:</b> {req.member?.name} ({req.member?.email})</p>
                <p><b>Status:</b> {req.status}</p>
                {req.status === 'pending' && (
                  <div className="request-actions">
                    <button onClick={() => handleStatus(req._id, 'approved')} className="approve-btn">Approve</button>
                    <button onClick={() => handleStatus(req._id, 'rejected')} className="reject-btn">Reject</button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
};

export default SponsorshipRequestsAdmin;
