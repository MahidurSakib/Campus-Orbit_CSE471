import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './Workspace.css';

const Workspace = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [resources, setResources] = useState([]);
  const token = localStorage.getItem('token');
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/resources`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setResources(data.resources);
      });
  }, [selectedClub, token]);

  const handleDelete = (resourceId, uploaderId) => {
    const selfId = localStorage.getItem('userId');
    const userType = localStorage.getItem('userType');

    if (userType !== 'club_admin' && selfId !== uploaderId) {
      alert('You can only delete your own resources');
      return;
    }

    if (!window.confirm('Delete this resource?')) return;

    fetch(`/api/club/${selectedClub._id}/resource/${resourceId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          alert('Resource deleted');
          setResources(resources.filter(r => r._id !== resourceId));
        } else {
          alert('Failed to delete resource');
        }
      });
  };

  return (
    <>
      <Header />
      <main className="workspace">
        <h1>Club Workspace</h1>
        <button onClick={() => navigate('/resource-upload')} className="upload-btn">
          Upload Resource
        </button>
        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="workspace-select"
            value={selectedClub?.id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>
                {club.name}
              </option>
            ))}
          </select>
        </div>
        {selectedClub && (
          <>
            {resources.length === 0 ? (
              <p>No resources uploaded yet.</p>
            ) : (
              <ul className="resource-list">
                {resources.map(resource => (
                  <li key={resource._id} className="resource-item">
                    <p>{resource.title}</p>
                    {resource.type === 'file' ? (
                      <a
                        href={`/uploads/${resource.fileUrl.split('/').pop()}`}
                        download
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Download File
                      </a>
                    ) : (
                      <a href={resource.linkUrl} target="_blank" rel="noopener noreferrer">
                        Open Link
                      </a>
                    )}
                    <p>Uploaded on {new Date(resource.uploadedAt).toLocaleDateString()}</p>
                    <button
                      onClick={() => handleDelete(resource._id, resource.uploader._id)}
                      className="delete-btn"
                    >
                      Delete
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </main>
    </>
  );
};

export default Workspace;
