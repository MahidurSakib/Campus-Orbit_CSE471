import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubEventsView.css';

const ClubEventsView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [events, setEvents] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setClubs(data.clubs); });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/event`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setEvents(data.events); });
  }, [selectedClub, token]);

  const signupVolunteer = async (eventId) => {
    const confirm = window.confirm('Sign up as a volunteer for this event?');
    if (!confirm) return;

    const res = await fetch(`/api/club/${selectedClub._id}/event/${eventId}/signup`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert('Volunteer sign-up successful');
      setEvents(prev => prev.map(e => e._id === eventId ? data.event : e));
    } else {
      alert(data.message || 'Failed to sign up');
    }
  };

  return (
    <>
      <Header />
      <main className="club-events-view">
        <h1>Volunteer for Club Events</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="event-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => <option key={club._id} value={club._id}>{club.name}</option>)}
          </select>
        </div>

        {selectedClub && (
          <>
            {events.length === 0 ? (
              <p>No events available for volunteer signup.</p>
            ) : (
              <ul className="event-list mt-6 space-y-4">
                {events.map(eventItem => {
                  if (!eventItem || !Array.isArray(eventItem.volunteers)) return null; // Defensive check
                  const hasSignedUp = eventItem.volunteers.some(v => v.user === localStorage.getItem('userId'));
                  return (
                    <li key={eventItem._id} className="event-card">
                      <div>
                        <h3>{eventItem.name}</h3>
                        <p>{eventItem.description}</p>
                      </div>
                      {hasSignedUp ? (
                        <span className="signed-up">Signed Up</span>
                      ) : (
                        <button
                          onClick={() => signupVolunteer(eventItem._id)}
                          className="signup-btn"
                        >
                          Sign Up
                        </button>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </>
        )}
      </main>
    </>
  );
};

export default ClubEventsView;
