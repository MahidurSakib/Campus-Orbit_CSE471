import React from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './DashboardAdmin.css';

const DashboardAdmin = () => {
  const navigate = useNavigate();

  return (
    <>
      <Header />
      <main className="dashboard-admin">
        <h1>Club Admin Dashboard</h1>
        <p>Welcome, club officer! Manage your club and members here.</p>

        <div className="button-group">
          <button
            onClick={() => navigate('/club/create')}
            className="dashboard-btn"
          >
            Create New Club
          </button>

          <button
            onClick={() => navigate('/club/manage')}
            className="dashboard-btn"
          >
            Manage Clubs & Members
          </button>
          <button
            onClick={() => navigate('/club/:clubId/tasks')}
            className="dashboard-btn"
          >
            Assign & Track Member Tasks
          </button>

          <button
            onClick={() => navigate('/club/announcements/manage')}
            className="dashboard-btn"
          >
            Manage Announcements
          </button>

          <button
            onClick={() => navigate('/club/activity/manage')}
            className="dashboard-btn"
          >
            Manage Activity Log
          </button>

          <button
            onClick={() => navigate('/club/meetings/manage')}
            className="dashboard-btn"
          >
            Manage Meetings
          </button>

          <button
            onClick={() => navigate('/club/polls/manage')}
            className="dashboard-btn"
          >
            Manage Polls
          </button>

          <button
            onClick={() => navigate('/workspace')}
            className="dashboard-btn"
          >
            Workspace
          </button>

          <button
            onClick={() => navigate('/club/events/manage')}
            className="dashboard-btn"
          >
            Manage Events
          </button>

          <button
            onClick={() => navigate('/club/achievements/manage')}
            className="dashboard-btn"
          >
            Manage Achievements
          </button>

          <button
            onClick={() => navigate('/feedback/view')}
            className="dashboard-btn"
          >
            View Feedback
          </button>

          <button
            onClick={() => navigate('/club/contacts/manage')}
            className="dashboard-btn"
          >
            Manage Contacts
          </button>
            <button
              onClick={() => navigate('/events')}
              className="dashboard-btn"
            >
              Event Portal
            </button>
              <button
                onClick={() => navigate('/events/mine')}
                className="dashboard-btn"
              >
                My Created Events
              </button>
        </div>
      </main>
    </>
  );
};

export default DashboardAdmin;
