import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubMeetingsView.css';

const ClubMeetingsView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [meetings, setMeetings] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;

    fetch(`/api/club/${selectedClub._id}/meetings`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setMeetings(data.meetings);
      });
  }, [selectedClub, token]);

  const markAttendance = async (meetingId) => {
    const confirm = window.confirm('Mark yourself as present for this meeting?');
    if (!confirm) return;

    const res = await fetch(`/api/club/${selectedClub._id}/meeting/${meetingId}/attendance`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert('Attendance marked present');
      // Refresh meetings data
      fetch(`/api/club/${selectedClub._id}/meetings`, { headers: { Authorization: `Bearer ${token}` } })
        .then(res => res.json())
        .then(data => {
          if (data.success) setMeetings(data.meetings);
        });
    } else {
      alert(data.message || 'Failed to mark attendance');
    }
  };

  return (
    <>
      <Header />
      <main className="club-meetings-view">
        <h1>Club Meetings & Attendance</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="meeting-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setMeetings([]);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <section className="mt-6 space-y-6">
            {meetings.length === 0 ? (
              <p>No meetings scheduled.</p>
            ) : (
              meetings.map(meeting => {
                const attendanceRec = meeting.attendance.find(att => att.user === localStorage.getItem('userId'));
                const isPresent = attendanceRec ? attendanceRec.status === 'present' : false;

                return (
                  <div key={meeting._id} className="meeting-card">
                    <h3>{meeting.title}</h3>
                    <p>{meeting.description}</p>
                    <p>Date: {new Date(meeting.date).toLocaleString()}</p>
                    <p>Attendance: {isPresent ? 'Present' : 'Absent'}</p>
                    {!isPresent && (
                      <button
                        onClick={() => markAttendance(meeting._id)}
                        className="mark-attendance-btn"
                      >
                        Mark Present
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </section>
        )}
      </main>
    </>
  );
};

export default ClubMeetingsView;
