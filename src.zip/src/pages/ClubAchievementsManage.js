import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubAchievementsManage.css';

const ClubAchievementsManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [achievements, setAchievements] = useState([]);
  const [awardTitle, setAwardTitle] = useState('');
  const [awardDescription, setAwardDescription] = useState('');
  const [awardBadgeUrl, setAwardBadgeUrl] = useState('');
  const [members, setMembers] = useState([]);
  const [memberToAward, setMemberToAward] = useState('');
  const [selectedAchievement, setSelectedAchievement] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setClubs(data.clubs); });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/achievements`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        console.log("Achievements API response:", data);
        if (data.success) {
          setAchievements(data.allAchievements);
          fetchMembers(selectedClub._id);
        }
      });
  }, [selectedClub, token]);

  const fetchMembers = async (clubId) => {
    const res = await fetch(`/api/club/${clubId}`, { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    if (data.success) {
      setMembers(data.club.members);
    }
  };

  const handleCreateAchievement = async (e) => {
    e.preventDefault();
    if (!awardTitle.trim()) {
      alert('Title is required');
      return;
    }
    const res = await fetch(`/api/club/${selectedClub._id}/achievement`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ title: awardTitle, description: awardDescription, badgeUrl: awardBadgeUrl }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Achievement created');
      setAwardTitle('');
      setAwardDescription('');
      setAwardBadgeUrl('');
      setAchievements(prev => [...prev, data.achievement]);
    } else {
      alert(data.message || 'Creation failed');
    }
  };

  const handleAwardAchievement = async () => {
    if (!selectedAchievement || !memberToAward) {
      alert("Please select both an achievement and a member");
      return;
    }
    const res = await fetch(`/api/club/${selectedClub._id}/achievement/${selectedAchievement}/award`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ memberId: memberToAward }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Achievement awarded');
    } else {
      let errorMsg = 'Failed to award';
      if (data.message) errorMsg += `: ${data.message}`;
      if (data.error) errorMsg += `\nDetails: ${data.error}`;
      alert(errorMsg);
    }
  };

  const handleDeleteAchievement = async (achievementId) => {
    if (!window.confirm('Delete this achievement?')) return;
    const res = await fetch(`/api/club/${selectedClub._id}/achievement/${achievementId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert('Achievement deleted');
      setAchievements(prev => prev.filter(a => a._id !== achievementId));
    } else {
      alert(data.message || 'Failed to delete');
    }
  };

  return (
    <>
      <Header />
      <main className="club-achievements">
        <h1>Manage Achievements & Badges</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="club-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setAchievements([]);
              setMembers([]);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}
          </select>
        </div>

        {selectedClub && (
          <>
            <form onSubmit={handleCreateAchievement} className="register-form mb-6">
              <input
                type="text"
                placeholder="Achievement Title"
                value={awardTitle}
                onChange={e => setAwardTitle(e.target.value)}
                className="club-input"
                required
              />
              <input
                type="text"
                placeholder="Badge URL"
                value={awardBadgeUrl}
                onChange={e => setAwardBadgeUrl(e.target.value)}
                className="club-input"
              />
              <textarea
                placeholder="Description"
                value={awardDescription}
                onChange={e => setAwardDescription(e.target.value)}
                className="club-textarea"
                rows={3}
              />
              <button type="submit" className="create-btn">
                Create Achievement
              </button>
            </form>

            <div className="mb-6">
              <h2>Award Achievement</h2>
              <select
                className="club-select"
                value={selectedAchievement}
                onChange={e => setSelectedAchievement(e.target.value)}
              >
                <option value="">-- Select Achievement --</option>
                {achievements.map(a => <option key={a._id} value={a._id}>{a.title}</option>)}
              </select>
              <select
                className="club-select"
                value={memberToAward}
                onChange={e => setMemberToAward(e.target.value)}
              >
                <option value="">-- Select Member --</option>
                {members.map(m => <option key={m._id} value={m._id}>{m.name}</option>)}
              </select>
              <button onClick={handleAwardAchievement} className="award-btn">
                Award Achievement
              </button>
            </div>

            <section>
              <h2>Current Achievements</h2>
              {achievements.length === 0 ? (
                <p>No achievements created yet.</p>
              ) : (
                <ul className="achievements-list">
                  {achievements.map(a => (
                    <li key={a._id} className="achievement-card">
                      <div>
                        <p className="font-semibold">{a.title}</p>
                        <p>{a.description}</p>
                        {a.badgeUrl && <img src={a.badgeUrl} alt="badge" className="badge" />}
                      </div>
                      <button onClick={() => handleDeleteAchievement(a._id)} className="delete-btn">
                        Delete
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubAchievementsManage;
