import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './ViewVolunteers.css';

const ViewVolunteers = () => {
  const { clubId, eventId } = useParams();
  const [volunteers, setVolunteers] = useState([]);
  const [eventName, setEventName] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchVolunteers = async () => {
      try {
        const token = localStorage.getItem('token');
        // Fetch volunteers
        const res = await axios.get(`/api/club/${clubId}/event/${eventId}/volunteers`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setVolunteers(res.data.volunteers || []);
        // Fetch event details for name
        const eventRes = await axios.get(`/api/club/${clubId}/event`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        const eventList = eventRes.data.events || [];
        const eventObj = eventList.find(e => e._id === eventId);
        setEventName(eventObj ? eventObj.name : '');
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch volunteers');
      } finally {
        setLoading(false);
      }
    };
    fetchVolunteers();
  }, [clubId, eventId]);

  if (loading) return <div className="volunteers-loading">Loading volunteers...</div>;
  if (error) return <div className="volunteers-error">{error}</div>;

  return (
    <>
      <Header />
      <div className="volunteers-container">
        <h2>Volunteers for Event{eventName ? `: ${eventName}` : ''}</h2>
        {volunteers.length === 0 ? (
          <div className="volunteers-empty">No volunteers have signed up yet.</div>
        ) : (
          <ul className="volunteers-list">
            {volunteers.map((v) => (
              <li key={v.user._id || v.user} className="volunteer-card">
                <div><strong>Name:</strong> {v.user.name || 'Unknown'}</div>
                <div><strong>Email:</strong> {v.user.email || 'N/A'}</div>
                <div><strong>Signed Up At:</strong> {v.signedUpAt ? new Date(v.signedUpAt).toLocaleString() : 'N/A'}</div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
};

export default ViewVolunteers;
