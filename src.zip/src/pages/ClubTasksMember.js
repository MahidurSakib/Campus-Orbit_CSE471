import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubTasksMember.css';

const ClubTasksMember = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [progressUpdate, setProgressUpdate] = useState({});

  useEffect(() => {
    fetch('/api/tasks/my-tasks', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    })
      .then(res => res.json())
      .then(data => {
        setTasks(data.tasks || []);
        setLoading(false);
      });
  }, []);

  const handleProgress = async (taskId) => {
    const progress = progressUpdate[taskId] || '';
    if (!progress) return;
    const res = await fetch(`/api/tasks/progress/${taskId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` },
      body: JSON.stringify({ progress }),
    });
    const data = await res.json();
    if (data.success) {
      setTasks(prev => prev.map(t => t._id === taskId ? data.task : t));
      setProgressUpdate(prev => ({ ...prev, [taskId]: '' }));
      alert('Progress updated!');
    } else {
      alert(data.message || 'Failed to update progress');
    }
  };

  return (
    <>
      <Header />
      <main className="club-tasks-member">
        <h1 className="tasks-title">My Assigned Tasks</h1>
        {loading ? <p className="tasks-loading">Loading tasks...</p> : tasks.length === 0 ? <p className="tasks-empty">No tasks assigned yet.</p> : (
          <div className="tasks-list">
            {tasks.map(task => (
              <div key={task._id} className="task-box">
                <p className="task-club"><b>Club:</b> {task.club?.name}</p>
                <p className="task-desc"><b>Description:</b> {task.description}</p>
                <p className="task-status"><b>Status:</b> <span className={
                  task.status === 'completed' ? 'status-completed' :
                  task.status === 'in-progress' ? 'status-inprogress' : 'status-pending'
                }>{task.status.charAt(0).toUpperCase() + task.status.slice(1)}</span></p>
                <p className="task-progress"><b>Progress:</b> {task.progress || 'No update yet.'}</p>
                {task.status !== 'completed' && (
                  <div className="task-progress-update">
                    <textarea
                      value={progressUpdate[task._id] || ''}
                      onChange={e => setProgressUpdate(prev => ({ ...prev, [task._id]: e.target.value }))}
                      placeholder="Type your progress update..."
                      rows={2}
                      className="task-progress-textarea"
                    />
                    <button onClick={() => handleProgress(task._id)} className="task-progress-btn">Update Progress</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </>
  );
};

export default ClubTasksMember;
