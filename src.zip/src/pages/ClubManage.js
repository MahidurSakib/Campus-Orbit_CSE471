import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubManage.css';

const ClubManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [members, setMembers] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [inviteEmail, setInviteEmail] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;

    fetch(`/api/club/${selectedClub._id}`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setMembers(data.club.members);
          setInvitations(data.club.invitations);
        }
      });
  }, [selectedClub, token]);

  const inviteMember = async () => {
    if (!inviteEmail) return alert('Enter email to invite');
    const res = await fetch(`/api/club/${selectedClub._id}/invite`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ email: inviteEmail }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Invitation sent');
      setInviteEmail('');
      setSelectedClub({ ...selectedClub });
    } else alert(data.message || 'Failed to send invitation');
  };

  const removeMember = async (memberId) => {
    if (!window.confirm('Remove this member?')) return;
    const res = await fetch(`/api/club/${selectedClub._id}/member/${memberId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert('Member removed');
      setSelectedClub({ ...selectedClub });
    } else alert(data.message || 'Failed to remove member');
  };

  return (
    <>
      <Header />
      <main className="club-manage">
        <h1>Manage Your Clubs & Members</h1>

        <div>
          <h2>Your Clubs</h2>
          <select
            className="club-select"
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
            }}
            value={selectedClub?._id || ''}
          >
            <option value="">Select a club</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <section>
            <h3>Members</h3>
            <ul className="members-list">
              {members.map(member => (
                <li key={member._id}>
                  <span>{member.name} ({member.email})</span>
                  <button
                    onClick={() => removeMember(member._id)}
                    className="remove-btn"
                  >
                    Remove
                  </button>
                </li>
              ))}
              {!members.length && <p>No members yet.</p>}
            </ul>

            <div>
              <h3>Pending Invitations</h3>
              <ul className="invitations-list">
                {invitations.map(inv => (
                  <li key={inv._id}>{inv.name} ({inv.email})</li>
                ))}
                {!invitations.length && <p>No pending invitations.</p>}
              </ul>

              <input
                type="email"
                placeholder="Email to invite"
                value={inviteEmail}
                onChange={e => setInviteEmail(e.target.value)}
                className="club-input"
              />
              <button onClick={inviteMember} className="invite-btn">
                Send Invitation
              </button>
            </div>
          </section>
        )}
      </main>
    </>
  );
};

export default ClubManage;
