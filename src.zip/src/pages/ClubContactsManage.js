import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubContactsManage.css';

const ClubContactsManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [contacts, setContacts] = useState([]);
  const [name, setName] = useState('');
  const [roleInClub, setRoleInClub] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setClubs(data.clubs); });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/contacts`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setContacts(data.contacts); });
  }, [selectedClub, token]);

  const handleAddContact = async (e) => {
    e.preventDefault();
    if (!name.trim() || !roleInClub.trim() || !contactEmail.trim()) {
      alert('All fields are required');
      return;
    }
    const res = await fetch(`/api/club/${selectedClub._id}/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ name, roleInClub, contactEmail }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Contact added');
      setName('');
      setRoleInClub('');
      setContactEmail('');
      setContacts(prev => [...prev, data.contact]);
    } else {
      alert(data.message || 'Failed to add contact');
    }
  };

  const handleDeleteContact = async (contactId) => {
    const confirm = window.confirm('Delete this contact?');
    if (!confirm) return;
    const res = await fetch(`/api/club/${selectedClub._id}/contact/${contactId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert('Contact deleted');
      setContacts(prev => prev.filter(c => c._id !== contactId));
    } else {
      alert(data.message || 'Failed to delete contact');
    }
  };

  const handleEditContact = async (contactId) => {
    const newName = prompt('Enter new name');
    const newRole = prompt('Enter new role');
    const newEmail = prompt('Enter new email');
    if (!newName || !newRole || !newEmail) return;
    const res = await fetch(`/api/club/${selectedClub._id}/contact/${contactId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ name: newName, roleInClub: newRole, contactEmail: newEmail }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Contact updated');
      setContacts(prev =>
        prev.map(c => (c._id === contactId ? data.contact : c))
      );
    } else {
      alert(data.message || 'Failed to update contact');
    }
  };

  return (
    <>
      <Header />
      <main className="club-contacts-manage">
        <h1>Manage Contact Directory</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="contact-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setContacts([]);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(c => (
              <option key={c._id} value={c._id}>{c.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            <form onSubmit={handleAddContact} className="contact-form max-w-md space-y-4 mb-6">
              <input
                type="text"
                placeholder="Name"
                value={name}
                onChange={e => setName(e.target.value)}
                className="contact-input"
                required
              />
              <input
                type="text"
                placeholder="Role in Club"
                value={roleInClub}
                onChange={e => setRoleInClub(e.target.value)}
                className="contact-input"
                required
              />
              <input
                type="email"
                placeholder="Contact Email"
                value={contactEmail}
                onChange={e => setContactEmail(e.target.value)}
                className="contact-input"
                required
              />
              <button
                type="submit"
                className="add-btn"
              >
                Add Contact
              </button>
            </form>

            <section>
              <h2>Contact Directory</h2>
              {contacts.length === 0 ? (
                <p>No contacts available.</p>
              ) : (
                <ul className="contact-list">
                  {contacts.map(contact => (
                    <li key={contact._id} className="contact-card">
                      <div>
                        <p className="font-semibold">{contact.name}</p>
                        <p>{contact.roleInClub}</p>
                        <p>{contact.contactEmail}</p>
                      </div>
                      <div>
                        <button
                          onClick={() => handleEditContact(contact._id)}
                          className="edit-btn"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteContact(contact._id)}
                          className="delete-btn"
                        >
                          Delete
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubContactsManage;
