import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubActivityView.css';

const ClubActivityView = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [activityLog, setActivityLog] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/joinedclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setClubs(data.clubs);
      });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/activity`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setActivityLog(data.activityLog);
      });
  }, [selectedClub, token]);

  return (
    <>
      <Header />
      <main className="club-activity-view">
        <h1>Club Activity Log</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="club-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setActivityLog([]);
            }}
          >
            <option value="">-- Select a club --</option>
            {clubs.map(club => (
              <option key={club._id} value={club._id}>{club.name}</option>
            ))}
          </select>
        </div>

        {selectedClub && (
          <>
            {activityLog.length === 0 ? (
              <p>No activities recorded for this club yet.</p>
            ) : (
              <ul className="activity-list">
                {activityLog.map((activity, i) => (
                  <li key={i} className="activity-card">
                    <p>{activity.description}</p>
                    <div className="photos">
                      {activity.photos && activity.photos.map((photo, idx) => (
                        <img
                          key={idx}
                          src={photo}
                          alt="Activity"
                          className="photo-thumbnail"
                        />
                      ))}
                    </div>
                    <p className="timestamp">{new Date(activity.date).toLocaleString()}</p>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </main>
    </>
  );
};

export default ClubActivityView;
