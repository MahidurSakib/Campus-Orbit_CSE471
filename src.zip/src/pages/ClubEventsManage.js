import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './ClubEventsManage.css';

const ClubEventsManage = () => {
  const [clubs, setClubs] = useState([]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [events, setEvents] = useState([]);
  const [eventName, setEventName] = useState('');
  const [eventDescription, setEventDescription] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/club/myclubs', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setClubs(data.clubs); });
  }, [token]);

  useEffect(() => {
    if (!selectedClub) return;
    fetch(`/api/club/${selectedClub._id}/event`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => { if (data.success) setEvents(data.events); });
  }, [selectedClub, token]);

  const handleCreateEvent = async (e) => {
    e.preventDefault();
    if (!eventName.trim()) {
      alert('Event name is required');
      return;
    }
    const res = await fetch(`/api/club/${selectedClub._id}/event`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ name: eventName, description: eventDescription }),
    });
    const data = await res.json();
    if (data.success) {
      alert('Event created successfully');
      setEventName('');
      setEventDescription('');
      setEvents(prev => [data.event, ...prev]);
    } else {
      alert(data.message || 'Event creation failed');
    }
  };

  const handleDeleteEvent = async (eventId) => {
    const confirm = window.confirm('Are you sure you want to delete this event?');
    if (!confirm) return;

    const res = await fetch(`/api/club/${selectedClub._id}/event/${eventId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert('Event deleted');
      setEvents(prev => prev.filter(e => e._id !== eventId));
    } else {
      alert(data.message || 'Failed to delete event');
    }
  };

  const { useNavigate } = require('react-router-dom');
  const navigate = useNavigate();
  const viewVolunteers = (eventId) => {
    if (!selectedClub || !eventId) return;
    navigate(`/clubs/${selectedClub._id}/events/${eventId}/volunteers`);
  };

  return (
    <>
      <Header />
      <main className="club-events-manage">
        <h1>Manage Events & Volunteers</h1>

        <div>
          <label htmlFor="club-select">Select Club</label>
          <select
            id="club-select"
            className="event-select"
            value={selectedClub?._id || ''}
            onChange={e => {
              const club = clubs.find(c => c._id === e.target.value);
              setSelectedClub(club);
              setEvents([]);
            }}
          >
            <option value="">-- Select Club --</option>
            {clubs.map(club => <option key={club._id} value={club._id}>{club.name}</option>)}
          </select>
        </div>

        {selectedClub && (
          <>
            <form onSubmit={handleCreateEvent} className="event-form mt-6 max-w-md flex flex-col gap-4">
              <input
                type="text"
                placeholder="Event Name"
                value={eventName}
                onChange={e => setEventName(e.target.value)}
                className="event-input"
                required
              />
              <textarea
                placeholder="Event Description"
                value={eventDescription}
                onChange={e => setEventDescription(e.target.value)}
                rows={3}
                className="event-textarea"
              />
              <button type="submit" className="create-btn">
                Create Event
              </button>
            </form>

            <section className="mt-8">
              <h2>Events</h2>
              {events.length === 0 ? (
                <p>No events created yet.</p>
              ) : (
                <ul className="event-list">
                  {events.map(eventItem => (
                    <li key={eventItem._id} className="event-card">
                      <div>
                        <h3>{eventItem.name}</h3>
                        <p>{eventItem.description}</p>
                      </div>
                      <div>
                        <button onClick={() => viewVolunteers(eventItem._id)} className="view-btn">
                          View Volunteers ({eventItem.volunteers?.length || 0})
                        </button>
                        <button onClick={() => handleDeleteEvent(eventItem._id)} className="delete-btn">
                          Delete Event
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>
    </>
  );
};

export default ClubEventsManage;
