
import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './EventCalendar.css';

function getMonthMatrix(year, month) {
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const matrix = [];
  let week = [];
  let dayOfWeek = firstDay.getDay();
  for (let i = 0; i < dayOfWeek; i++) week.push(null);
  for (let d = 1; d <= lastDay.getDate(); d++) {
    week.push(new Date(year, month, d));
    if (week.length === 7) {
      matrix.push(week);
      week = [];
    }
  }
  if (week.length) {
    while (week.length < 7) week.push(null);
    matrix.push(week);
  }
  return matrix;
}

const EventCalendar = () => {
  const [events, setEvents] = useState([]);
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    fetch('/api/events')
      .then(res => res.json())
      .then(data => {
        if (data.success) setEvents(data.events);
      });
  }, []);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthMatrix = getMonthMatrix(year, month);

  // Map events to days
  const eventsByDay = {};
  events.forEach(event => {
    const date = new Date(event.date);
    if (date.getFullYear() === year && date.getMonth() === month) {
      const day = date.getDate();
      if (!eventsByDay[day]) eventsByDay[day] = [];
      eventsByDay[day].push(event.title);
    }
  });

  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  return (
    <>
      <Header />
      <main className="event-calendar">
        <h1>{monthName} {year}</h1>
        <div className="calendar-grid">
          <div className="calendar-row calendar-header">
            {['S','M','T','W','T','F','S'].map(d => (
              <div key={d} className="calendar-cell calendar-header-cell">{d}</div>
            ))}
          </div>
          {monthMatrix.map((week, i) => (
            <div key={i} className="calendar-row">
              {week.map((date, j) => (
                <div key={j} className="calendar-cell">
                  {date && (
                    <>
                      <div className="calendar-date">{date.getDate()}</div>
                      {eventsByDay[date.getDate()] && (
                        <div className="calendar-events">
                          {eventsByDay[date.getDate()].map((title, idx) => (
                            <div key={idx} className="calendar-event-name">{title}</div>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </main>
    </>
  );
};

export default EventCalendar;
