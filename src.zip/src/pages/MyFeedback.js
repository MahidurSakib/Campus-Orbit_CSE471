import React, { useEffect, useState } from 'react';
import Header from '../components/Header';

const MyFeedback = () => {
  const token = localStorage.getItem('token');
  const [clubs, setClubs] = useState([]);
  const [club, setClub] = useState(null);
  const [items, setItems] = useState([]);     // my feedbacks for selected club
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');
  const [error, setError] = useState('');

  // Load clubs I joined
  useEffect(() => {
    async function loadClubs() {
      try {
        const res = await fetch('/api/user/joinedclubs', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        if (data.success) setClubs(data.clubs || []);
          else {
            setError(data.message || 'Failed to fetch clubs');
          }
        } catch (e) {
          setError('Failed to fetch clubs');
      }
    }
    if (token) loadClubs();
  }, [token]);

  // Load my feedbacks for selected club
  useEffect(() => {
    async function loadMyFeedbacks() {
      if (!club?._id) return;
      setLoading(true);
      setError('');
      try {
        const res = await fetch(`/api/club/${club._id}/feedbacks/mine`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        if (data.success) {
          setItems(data.feedbacks || []);
        } else {
          setError(data.message || 'Failed to fetch feedback');
        }
      } catch (e) {
        setError('Failed to fetch feedback');
      } finally {
        setLoading(false);
      }
    }
    if (token) loadMyFeedbacks();
  }, [club, token]);

  const beginEdit = (fb) => {
    setEditingId(fb._id);
    setEditText(fb.message || '');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditText('');
  };

  const saveEdit = async () => {
    if (!club?._id || !editingId) return;
    try {
      const res = await fetch(`/api/club/${club._id}/feedback/${editingId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ message: editText })
      });
      const data = await res.json();
      if (data.success) {
        setItems(prev => prev.map(f => (f._id === editingId ? data.feedback : f)));
        cancelEdit();
        alert('Feedback updated');
      } else {
        alert(data.message || 'Update failed');
      }
    } catch (e) {
      alert('Update failed');
    }
  };

  return (
    <>
      <Header />
      <main className="my-feedback-page" style={{ maxWidth: 800, margin: '0 auto', padding: '1.5rem' }}>
        <h1>My Feedback</h1>

        <div style={{ margin: '1rem 0' }}>
          <label htmlFor="club">Select Club: </label>
          <select
            id="club"
            value={club?._id || ''}
            onChange={(e) => setClub(clubs.find(c => c._id === e.target.value))}
          >
            <option value="">-- choose club --</option>
            {clubs.map(c => (
              <option key={c._id} value={c._id}>{c.name}</option>
            ))}
          </select>
        </div>

        {!club ? (
          <p>Select a club to view your feedback.</p>
        ) : loading ? (
          <p>Loading...</p>
        ) : error ? (
          <p style={{ color: 'crimson' }}>{error}</p>
        ) : items.length === 0 ? (
          <p>No feedback for this club yet.</p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0, display: 'grid', gap: '0.75rem' }}>
            {items.map(fb => (
              <li key={fb._id} style={{ border: '1px solid #eee', padding: '0.9rem', borderRadius: 8 }}>
                <p style={{ margin: '0 0 0.5rem' }}>
                  <b>Submitted:</b> {new Date(fb.createdAt).toLocaleString()}
                </p>

                {editingId === fb._id ? (
                  <>
                    <textarea
                      value={editText}
                      onChange={e => setEditText(e.target.value)}
                      rows={4}
                      style={{ width: '100%' }}
                    />
                    <div style={{ marginTop: '0.5rem', display: 'flex', gap: '0.5rem' }}>
                      <button onClick={saveEdit} className="save-btn">Save</button>
                      <button onClick={cancelEdit} className="cancel-btn">Cancel</button>
                    </div>
                  </>
                ) : (
                  <>
                    <p style={{ whiteSpace: 'pre-wrap' }}>{fb.message}</p>
                    <button onClick={() => beginEdit(fb)} className="edit-btn">Edit</button>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
};

export default MyFeedback;
