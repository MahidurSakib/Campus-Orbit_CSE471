import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import './Invitations.css';

const Invitations = () => {
  const [invitations, setInvitations] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetch('/api/user/invitations', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => {
        if (data.success) setInvitations(data.invitations);
      });
  }, []);

  const respondInvitation = async (clubId, action) => {
    const endpoint =
      action === 'accept'
        ? `/api/club/${clubId}/accept`
        : `/api/club/${clubId}/decline`;

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) {
      alert(`Invitation ${action}ed`);
      setInvitations(invitations.filter(inv => inv._id !== clubId));
    } else {
      alert(data.message || 'Failed to respond to invitation');
    }
  };

  return (
    <>
      <Header />
      <main className="invitations">
        <h1>Your Club Invitations</h1>
        {invitations.length === 0 ? (
          <p>You have no pending invitations.</p>
        ) : (
          <ul className="invitation-list">
            {invitations.map((club) => (
              <li key={club._id}>
                <span>{club.name}</span>
                <div>
                  <button
                    onClick={() => respondInvitation(club._id, 'accept')}
                    className="accept-btn"
                  >
                    Accept
                  </button>
                  <button
                    onClick={() => respondInvitation(club._id, 'decline')}
                    className="decline-btn"
                  >
                    Decline
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
};

export default Invitations;
