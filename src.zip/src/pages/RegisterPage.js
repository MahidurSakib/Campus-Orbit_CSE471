import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './RegisterPage.css';

const RegisterPage = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '', userType: 'student' });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setLoading(false);
    if (data.success) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('userType', data.userType);
      navigate(data.userType === 'club_admin' ? '/dashboard/admin' : '/dashboard/student');
    } else {
      alert(data.message || 'Registration failed');
    }
  };

  return (
    <>
      <Header />
      <main className="register-page">
        <form onSubmit={handleRegister} className="register-form">
          <h2>Register</h2>
          <input
            name="name"
            placeholder="Full Name"
            required
            value={form.name}
            onChange={handleChange}
            className="register-input"
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            required
            value={form.email}
            onChange={handleChange}
            className="register-input"
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            required
            value={form.password}
            onChange={handleChange}
            className="register-input"
          />
          <select
            name="userType"
            value={form.userType}
            onChange={handleChange}
            className="register-select"
          >
            <option value="student">Student</option>
            <option value="club_admin">Club Admin</option>
          </select>
          <button type="submit" disabled={loading} className="register-btn">
            {loading ? 'Registering...' : 'Register'}
          </button>
        </form>
      </main>
    </>
  );
};

export default RegisterPage;
